define( function() {

"use strict";

return /^--/;

} );
